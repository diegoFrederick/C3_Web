<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;


class UsuariosController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (Auth::user()->rol_id==1){
            $usuarios = Usuario::all();
            return view('admin.usuarios', compact('usuarios'));
        }elseif (Auth::user()->rol_id==2){
            $usuario = Usuario::find(Auth::user()->id);
            return view('home.usuario',compact('usuario'));
        }
        
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $usuario = new Usuario();
        $usuario->nombre= $request->nombre;
        $usuario->email= $request->email;
        $usuario->password=Hash::make($request->password);
        $usuario->rol_id=2;
        $usuario->save();
        return redirect()->route('home.login');

    }

    /**
     * Display the specified resource.
     */
    public function show(Usuario $usuario)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Usuario $usuario)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Usuario $usuario)
    {
        $usuario = Usuario::find($request->usuario);

        $usuario->nombre= $request->nombre;
        $usuario->email= $request->email;
        $usuario->save();

        return redirect()->route('admin.usuarios');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Usuario $usuario){
        $usuario->delete();
        return redirect()->route('admin.usuarios');
    }

    public function login(Request $request){

        //dd($request->only('email','password'));
        $credenciales = $request->only('email','password');
        //if (Auth::attempt(['email' => $email, 'password' => $password]))
        if (Auth::attempt($credenciales)){
            $usuario = Usuario::where('email',$request->email)->first();
            return redirect()->route('home.productos', compact('usuario'));
        }
        else{
            return back()->withErrors('Credenciales incorrectas');
        }

    }

    public function logout(){
        Auth::logout();
        return redirect()->route('home.login');
    }
}
