<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-custom.min.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container-fluid">

        <div class="row bg-dark text-white">
            <div class="row">
                <div class="col-8">
                    Bienvenido: <?php echo e(Auth::user()->nombre); ?>

                </div>

                <!-- cerrar sesión -->
                <div class="col-1 text-end d-none d-lg-block">
                    <a href="<?php echo e(route('usuarios.logout')); ?>" class="text-white">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </div>

    <!-- navbar -->
    <div class="container-fluid px-0">
        <nav class="navbar navbar-expand-lg bg-primary navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Shopp</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('admin.usuarios')); ?>" >Listado de usuarios</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('home.productos')); ?>" >Listado de productos</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo e(route('admin.ventas')); ?>">Listado de ventas</a>
                        </li>
                        
                        <li class="nav-item d-lg-none">
                            <a class="nav-link" >Cerrar Sesión</a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <hr>
    <div class="container-fluid min-vh-50 d-flex flex-column justify-content-lg-center">
        <div class="row">
            <div class="col-12 col-lg-8 offset-lg-2">
                <div class="row bg-light" style="height: 25rem;">
                    <div class="col-lg-8 bg-dark">
                        <h4 class="text-white">Usuarios</h4>
                        <div class="card">
                            <div class="card-body">
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card" style="width: 18rem;">
                                        <img src="<?php echo e(asset('images/usuario.jpg')); ?>" class="card-img-top" alt="...">
                                        <div class="card-body">

                                            <h5 class="card-title">ID: <?php echo e($usuario->id); ?></h5>
                                            <p class="card-text">Nombre: <?php echo e($usuario->nombre); ?></p>
                                            <p class="card-text">Email: <?php echo e($usuario->email); ?></p>
                                        </div>
                                        <?php if($usuario->rol_id==2): ?>
                                            <form method="POST" action="<?php echo e(route('usuarios.destroy',$usuario->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger pb-0" data-bs-toggle="tooltip"
                                                data-bs-title="Borrar <?php echo e($usuario->nombre); ?>"><span class="material-icons">delete</span></button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\diego\Downloads\C3_web\resources\views/admin/usuarios.blade.php ENDPATH**/ ?>