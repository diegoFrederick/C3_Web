<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UsuariosController;
use App\Http\Controllers\ProductosController;
use App\Http\Controllers\VentasController;

Route::get('/',[HomeController::class,'login'])->name('home.login');
route::get('/registrar',[HomeController::class,'registrar'])->name('home.registrar');
route::get('/comprador',[HomeController::class,'index'])->name('comprador.index');
route::get('/venta',[HomeController::class,'ventas'])->name('home.ventas');

//Route::post('/ventas/store',[VentasController::class,'store'])->name('ventas.store');
route::get('/ventas',[VentasController::class,'index'])->name('admin.ventas');

route::get('/productos',[ProductosController::class,'index'])->name('home.productos');
Route::delete('/productos/{producto}',[ProductosController::class,'destroy'])->name('productos.destroy');
Route::post('/productos/store',[ProductosController::class,'store'])->name('productos.store');
route::post('update',[ProductosController::class,'update'])->name('productos.update');
Route::post('/ventas/store',[ProductosController::class,'storeVenta'])->name('ventas.store');

route::get('/admin/usuarios',[UsuariosController::class,'index'])->name('admin.usuarios');
Route::post('/usuarios/perfil',[UsuariosController::class,'update'])->name('usuario.update');
Route::post('/usuarios/login',[UsuariosController::class,'login'])->name('usuarios.login');
Route::get('/usuarios/logout',[UsuariosController::class,'logout'])->name('usuarios.logout');
Route::post('/usuarios',[UsuariosController::class,'store'])->name('usuarios.store');
Route::delete('/usuarios/{usuario}',[UsuariosController::class,'destroy'])->name('usuarios.destroy');