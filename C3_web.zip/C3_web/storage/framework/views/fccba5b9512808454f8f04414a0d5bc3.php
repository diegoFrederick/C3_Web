<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-custom.min.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container-fluid">
        <div class="row bg-dark text-white">
            <div class="row">
                <div class="col-8">
                    Bienvenido: <?php echo e(Auth::user()->nombre); ?>

                </div>

                <!-- cerrar sesión -->
                <div class="col-1 text-end d-none d-lg-block">
                    <a href="<?php echo e(route('usuarios.logout')); ?>" class="text-white">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </div>

    <!-- navbar -->
    <div class="container-fluid px-0">
        <nav class="navbar navbar-expand-lg bg-primary navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Shopp</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <?php if(Auth::user()->rol_id==2): ?>
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('admin.usuarios')); ?>">Mi cuenta</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('home.productos')); ?>">Productos</a>
                            </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->rol_id==1): ?>
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('admin.usuarios')); ?>" >Listado de usuarios</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('home.productos')); ?>" >Listado de productos</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="<?php echo e(route('admin.ventas')); ?>">Listado de ventas</a>
                            </li>
                        <?php endif; ?>
                        
                        <li class="nav-item d-lg-none">
                            <a class="nav-link" >Cerrar Sesión</a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <hr>
    <div class="container-fluid min-vh-50 d-flex flex-column justify-content-lg-center">
        <div class="row">
            <div class="col-12 col-lg-8 offset-lg-2">
                <div class="row bg-light" style="height: 25rem;">
                    <div class="col-lg-8 bg-dark">
                        <h4 class="text-white">Productos</h4>
                        <div class="card">
                            <div class="card-body">
                                
                                <?php if(Auth::user()->rol_id==2): ?>
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num=>$producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card" style="width: 18rem;">
                                            <?php if($producto->cod_categoria==1): ?>
                                                <img src="<?php echo e(asset('images/lapiz.jpg')); ?>" class="card-img-top" alt="...">
                                
                                            <?php endif; ?>

                                            <?php if($producto->cod_categoria==2): ?>
                                                <img src="<?php echo e(asset('images/goma.jpg')); ?>" class="card-img-top" alt="...">
                                            <?php endif; ?>

                                            <?php if($producto->cod_categoria==3): ?>
                                                <img src="<?php echo e(asset('images/regla.png')); ?>" class="card-img-top" alt="...">
                                            <?php endif; ?>

                                            <?php if($producto->cod_categoria==4): ?>
                                                <img src="<?php echo e(asset('images/libros.jpg')); ?>" class="card-img-top" alt="...">
                                            <?php endif; ?>

                                            <?php if($producto->cod_categoria==5): ?>
                                                <img src="<?php echo e(asset('images/utiles.png')); ?>" class="card-img-top" alt="...">
                                            <?php endif; ?>
                                            <div class="card-body">
                                                <h5 class="card-title">Nombre: <?php echo e($producto->nombre); ?></h5>
                                                <p class="card-text">Precio: <?php echo e($producto->precio); ?></p>
                                                <p class="card-text">Stock: <?php echo e($producto->stock); ?></p>
                                                <?php if($producto->stock==0): ?>
                                                    <a href="#" class="btn btn-danger">Producto sin stock</a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                <?php if(Auth::user()->rol_id==1): ?>
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num=>$producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card" style="width: 18rem;">
                                            <?php if($producto->cod_categoria==1): ?>
                                                <img src="<?php echo e(asset('images/lapiz.jpg')); ?>" class="card-img-top" alt="...">
                                            <?php endif; ?>

                                            <?php if($producto->cod_categoria==2): ?>
                                                <img src="<?php echo e(asset('images/goma.jpg')); ?>" class="card-img-top" alt="...">
                                            <?php endif; ?>

                                            <?php if($producto->cod_categoria==3): ?>
                                                <img src="<?php echo e(asset('images/regla.png')); ?>" class="card-img-top" alt="...">
                                            <?php endif; ?>

                                            <?php if($producto->cod_categoria==4): ?>
                                                <img src="<?php echo e(asset('images/libros.jpg')); ?>" class="card-img-top" alt="...">
                                            <?php endif; ?>

                                            <?php if($producto->cod_categoria==5): ?>
                                                <img src="<?php echo e(asset('images/utiles.png')); ?>" class="card-img-top" alt="...">
                                            <?php endif; ?>
                                            <div class="card-body">
                                                <h5 class="card-title">Nombre: <?php echo e($producto->nombre); ?></h5>
                                                <p class="card-text">Precio: <?php echo e($producto->precio); ?></p>
                                                <p class="card-text">Stock: <?php echo e($producto->stock); ?></p>
                                                <?php if($producto->stock==0): ?>
                                                    <a href="#" class="btn btn-danger">Producto sin stock</a>
                                                <?php else: ?>
                                                    <?php if($producto->stock <= $producto->stockcritico): ?>
                                                        <a href="#" class="btn btn-danger">Producto bajo de stock</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                            <form method="POST" action="<?php echo e(route('productos.destroy',$producto->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger pb-0" data-bs-toggle="tooltip"
                                                data-bs-title="Borrar <?php echo e($producto->nombre); ?>"><span class="material-icons">delete</span></button>
                                            </form>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <!--
                                <div class="mb-3">
                                    <a class="link" href="{a{route('home.ventas')}}">Pasar a comprar</a>
                                </div>
                                -->
                            </div>
                        </div>
                    </div>
                    <!-- / FIN Formulario -->
                    
                    <?php if(Auth::user()->rol_id==2): ?>
                        <div class="col-12 col-lg-4 order-first order-lg-last">
                            <div class="card">
                                <div class="card-header bg-dark text-white">Producto seleccionado</div>
                                <div class="card-body">
                                    <form method="POST" action="<?php echo e(route('ventas.store')); ?>">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group">
                                            <label for="producto">Producto</label>
                                            <select class="form-control" name="producto" id="producto">
                                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->nombre); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="cantidad">Cantidad a comprar:</label>
                                            <input class="form-control" type="number" name="cantidad" id="cantidad" min="1" max="20">
                                        </div>
                                        <div class="mb-3 d-grid gap-2 d-lg-block">
                                            <button  type="reset" class="btn btn-warning">Cancelar</button>
                                            <button type="submit" class="btn btn-success">Realizar compra</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if(Auth::user()->rol_id==1): ?>
                        <div class="col-12 col-lg-4 order-first order-lg-last">
                            <div class="card">
                                <div class="card-header bg-dark text-white">Agregar producto</div>
                                <div class="card-body">
                                    <form method="POST" action="<?php echo e(route('productos.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label for="nombre" class="form-label">Nombre</label>
                                            <input type="text" id="nombre" name="nombre"  class="form-control">
                                        </div>
                                        <div class="mb-3">
                                            <label for="precio" class="form-label">Precio</label>
                                            <input type="number" id="precio" name="precio"  class="form-control">
                                        </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="stock">Stock inicial</label>
                                            <input class="form-control" type="number" name="stock" id="stock" min="1" max="100">
                                        </div>
                                        <div class="mb-3">
                                            <label for="critico">Stock critico</label>
                                            <input class="form-control" type="number" name="critico" id="critico" min="1" max="20">
                                        </div>
                                        <div class="mb-3">
                                            <label for="categoria" class="form-label">Categoria</label>
                                            <input type="number" id="categoria" name="categoria"  class="form-control">
                                        </div>
                                        <div class="mb-3 d-grid gap-2 d-lg-block">
                                            <button  type="reset" class="btn btn-warning">Cancelar</button>
                                            <button type="submit" class="btn btn-success">Agregar Producto</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-header bg-dark text-white">Editar producto</div>
                                <div class="card-body">
                                    <label for="producto">Producto a actualizar:</label>
                                    <form method="POST" action="<?php echo e(route('productos.update')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <select class="form-control" name="producto" id="producto">
                                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="mb-3">
                                            <label for="nombre" class="form-label">Nombre</label>
                                            <input type="text" id="nombre" name="nombre"  class="form-control">
                                        </div>
                                        <div class="mb-3">
                                            <label for="precio" class="form-label">Precio</label>
                                            <input type="number" id="precio" name="precio"  class="form-control">
                                        </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="stock">Stock actual</label>
                                            <input class="form-control" type="number" name="stock" id="stock" min="1" max="100">
                                        </div>
                                        <div class="mb-3">
                                            <label for="critico">Stock critico</label>
                                            <input class="form-control" type="number" name="critico" id="critico" min="1" max="20">
                                        </div>
                                        <div class="mb-3 d-grid gap-2 d-lg-block">
                                            <button  type="reset" class="btn btn-warning">Cancelar</button>
                                            <button type="submit" class="btn btn-success">Actualizar Producto</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\diego\Downloads\C3_web\resources\views/home/productos.blade.php ENDPATH**/ ?>