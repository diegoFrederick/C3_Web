<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Venta;
use App\Models\Producto;
use App\Models\Usuario;

class VentasController extends Controller
{
    public function index(){
        $ventas = Venta::all();
        $productos = Producto::all();
        $usuarios = Usuario::all();
        return view('admin.ventas',compact('productos','usuarios','ventas'));
    }

    public function store(Request $request)
    {
        
        $venta = new Venta();
        $producto = Producto::find($request->producto);
        if ($producto->stock<$request->cantidad){
            return redirect()->route('home.productos')->with('error', 'no se a podido realizar la compra, stock insuficiente');
        }
        $producto->stock=$producto->stock-$request->cantidad;
        $producto->save();

        $venta->usuario_id=Auth::user()->id;
        $venta->producto_id= $request->producto;
        $venta->cantidad= $request->cantidad;
        $venta->save();
        return redirect()->route('home.productos')->with('success', 'Compra registrada correctamente');

    }
}