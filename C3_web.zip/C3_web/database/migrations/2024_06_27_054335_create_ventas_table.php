<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ventas', function (Blueprint $table) {
            //$table->id('usuario_id');
            //$table->id('producto_id');
            $table->primary(['usuario_id', 'producto_id']);
            $table->unsignedBigInteger('usuario_id');
            $table->unsignedBigInteger('producto_id');
            $table->foreign('usuario_id')->references('id')->on('usuarios');
            $table->foreign('producto_id')->references('id')->on('productos');
            //$table->id('id_usuario');
            //$table->id('id_producto');
            $table->tinyInteger('cantidad');
            $table->integer('total');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ventas');
    }
};
