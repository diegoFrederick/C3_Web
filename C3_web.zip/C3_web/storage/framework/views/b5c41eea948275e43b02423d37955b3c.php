<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-custom.min.css')); ?>">
    <title>Creacion de cuenta</title>
</head>
<body style="background: linear-gradient(to bottom, #660066 0%, #ff99cc 100%);">
    <div class="container-fluid min-vh-100 d-flex flex-column justify-content-lg-center">
        <div class="row">
            <div class="col-12 col-lg-8 offset-lg-2">
                <div class="row bg-light">
                    <div class="row-lg-4 bg-primary d-flex flex-column justify-content-center align-items-center text-center" style="height: 15rem;">
                        <div class="bg-white p-2 mb-3 rounded">
                            <img src="<?php echo e(asset('images/usuario.jpg')); ?>" style="width: 7rem;">
                        </div>
                        <h4 class="text-light">Creacion de nueva cuenta</h4>
                    </div>

                    <div class="row-lg-8 bg-white d-flex flex-column justify-content-center align-items-center text-center" style="height: 30rem;">
                        
                        <div class="card">
                            <div class="card-body">
                                <div class="card-body">
                                    <form method="POST" action="<?php echo e(route('usuarios.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label for="nombre" class="form-label">Nombre</label>
                                            <input type="text" id="nombre" name="nombre"  class="form-control">
                                        </div>
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email</label>
                                            <input type="text" id="email" name="email"  class="form-control">
                                        </div>
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Contraseña</label>
                                            <input type="password" id="password" name="password" class="form-control">
                                        </div>
                                        <div class="mb-3 d-grid gap-2 d-lg-block">
                                            <button  type="reset" class="btn btn-warning">Cancelar</button>
                                            <button type="submit" class="btn btn-success">Crear</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="link" href="<?php echo e(route('home.login')); ?>">Atras</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\diego\Downloads\C3_web\resources\views/home/registrar.blade.php ENDPATH**/ ?>