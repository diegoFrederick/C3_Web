<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(){
        return view('home.index');
    }

    public function login(){
        return view('home.login');
    }

    public function registrar(){
        return view('home.registrar');
    }

    public function ventas(){
        return view('home.ventas');
    }
}