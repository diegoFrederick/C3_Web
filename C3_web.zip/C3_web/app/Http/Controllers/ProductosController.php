<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Producto;
use App\Models\Venta;

class ProductosController extends Controller
{
    public function index(){
        $productos = Producto::all();
        return view('home.productos',compact('productos'));
    }

    public function storeVenta(Request $request)
    {
        $venta = new Venta();
        $producto = Producto::find($request->producto);
        if ($producto->stock<$request->cantidad){
            return redirect()->route('home.productos')->with('error', 'no se a podido realizar la compra, stock insuficiente');
        }
        $producto->stock=$producto->stock-$request->cantidad;
        $producto->save();

        $venta->usuario_id=Auth::user()->id;
        $venta->producto_id= $request->producto;
        $venta->cantidad= $request->cantidad;
        $venta->save();
        return redirect()->route('home.productos')->with('success', 'Compra registrada correctamente');

    }

    public function store(Request $request)
    {
        $producto = new Producto();
        $producto->nombre= $request->nombre;
        $producto->precio= $request->precio;
        $producto->stock= $request->stock;
        $producto->stockcritico= $request->critico;
        $producto->cod_categoria=$request->categoria;
        $producto->save();
        return redirect()->route('home.productos')->with('success', 'Compra registrada correctamente');

    }

    public function update(Request $request){
        
        $producto = Producto::find($request->producto);

        $producto->nombre = $request->nombre;
        $producto->precio = $request->precio;
        $producto->stock = $request->stock;
        $producto->stockcritico = $request->critico;
        $producto->save();
    
        return redirect()->route('home.productos')->with('success', 'Producto actualizado correctamente');
        
    }

    public function destroy(Producto $producto){
        $producto->delete();
        return redirect()->route('home.productos');
    }
}